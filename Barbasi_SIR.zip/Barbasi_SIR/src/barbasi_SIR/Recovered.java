package barbasi_SIR;

import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.grid.Grid;

public class Recovered {
	private ContinuousSpace<Object> space;
	private Grid<Object> grid;
	
	public Recovered(ContinuousSpace<Object> space, Grid<Object> grid) {
		this.space = space;
		this.grid = grid;
	}
	
	
}