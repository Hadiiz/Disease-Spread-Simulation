package barbasi_SIR;


import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.grid.Grid;


public class Infected {
	private ContinuousSpace<Object> space;
	private Grid<Object> grid;
	
	public Infected(ContinuousSpace<Object> space, Grid<Object> grid ) {
		this.space = space;
		this.grid = grid;
	}

	
	

}
